export function formatResponse(text) {
  return `💬 Pancho dice:\n\n${text}`;
}
